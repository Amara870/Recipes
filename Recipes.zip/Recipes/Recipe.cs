﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipes
{
    public abstract class Recipe
    {
        //private attributes

        //example - 5 or 20
        private int prepTimeMinutes;
        //example pizza or pancakes
        private string recipeName;
        //example - italian or asian
        private string category;
        //example - flour salt apples
        private string ingredients;
        //example if not meat then this would be true
        private bool isVegetarian;
        //example - jane doe
        private string submittedBy;

        //public properties

        public int PrepTimeMinutes
        {
            get { return prepTimeMinutes; }
            set
            {
                if (value > 0)
                {
                    prepTimeMinutes = value;
                }
                else
                {
                    prepTimeMinutes = 0;
                }
            }
        }

        public string RecipeName { get; set; }

        public string Category { get; set; }

        public string Ingredients { get; set; }

        public string IsVegetarian { get; set; }

        public string SubmittedBy { get; set; }

        //methods
        //making this method abstract since our subclasses will display that info
        public abstract string Display();

        //this method can be overridden in the subclasses, if needed
        public virtual string Display(int num)
        {
            if (num == 1)
            {
                return RecipeName;
            }
            else if (num == 2)
            {
                return RecipeName + " " + Category;
            }
            else
            {
                return RecipeName + " " + Category + " " + Ingredients;
            }
        }


    }
}
