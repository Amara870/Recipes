﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipes
{
    public class MainDish : Recipe, IServingSuggestion
    {
        private bool isSpicy;

        public bool IsSpicy { get; set; }

        public override string Display()
        {
            return "Main Dish Name: " + RecipeName + " | Spicy? " + IsSpicy;
        }

        //this implents the required serving from the IServingSuggestion interface
        public string GetServingSuggestion()
        {
            return "This main dish should be eaten with friends";
        }
    }
}
