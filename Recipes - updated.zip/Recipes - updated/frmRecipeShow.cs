﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Recipes
{
    public partial class frmRecipeShow : Form
    {
        public frmRecipeShow()
        {
            InitializeComponent();
        }

        private void frmRecipeShow_Load(object sender, EventArgs e)
        {
            //this is our connection string to your mdf table
            string strConnString = @"Data Source=(LocalDB)\MSSQLLocaalDB;AttachDbFileName=C:\Users\ahill87105\source\repos\Recipes\Recipes\Recipe.mdf;Integrated Security=True;Connect Timeout=30";

            //simple query to return all runs
            string strQuery = "SELECT + FROM tblRecipe";

            //open a connection to the database
            using (SqlConnection connection = new SqlConnection(strConnString))
            {
                connection.Open();

                //set up the code so we can run a query with the resources managed for us
                using (SqlCommand cmd = new SqlCommand())
                {
                    //data adapter so the data can be used in our data grid view
                    SqlDataAdapter adapter = new SqlDataAdapter(strQuery, strConnString);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    dgvRecipe.DataSource = table;

                }

            }

        }
    }
}
