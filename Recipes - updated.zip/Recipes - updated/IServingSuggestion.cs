﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipes
{
    public interface IServingSuggestion
    {
        // this will be the method that any classes that implement this interface need to create 
        string GetServingSuggestion();
    }
}
