﻿namespace Recipes
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            lblPrepTimeMinutes = new Label();
            txtRecipeName = new TextBox();
            lblRecipeName = new Label();
            lblTypeofRecipe = new Label();
            txtIngredients = new TextBox();
            lblIngredients = new Label();
            txtSubmittedBy = new TextBox();
            lblVegetarian = new Label();
            lblSubmittedBy = new Label();
            numPrepTimeMinutes = new NumericUpDown();
            chbVegeterian = new CheckBox();
            cmbTypeOfRecipe = new ComboBox();
            chbSpicy = new CheckBox();
            lblIsSpicy = new Label();
            btnSaveRecipe = new Button();
            ((System.ComponentModel.ISupportInitialize)numPrepTimeMinutes).BeginInit();
            SuspendLayout();
            // 
            // lblPrepTimeMinutes
            // 
            lblPrepTimeMinutes.AutoSize = true;
            lblPrepTimeMinutes.Location = new Point(10, 39);
            lblPrepTimeMinutes.Margin = new Padding(2, 0, 2, 0);
            lblPrepTimeMinutes.Name = "lblPrepTimeMinutes";
            lblPrepTimeMinutes.Size = new Size(148, 20);
            lblPrepTimeMinutes.TabIndex = 0;
            lblPrepTimeMinutes.Text = "Prep Time in Minutes";
            // 
            // txtRecipeName
            // 
            txtRecipeName.Location = new Point(193, 83);
            txtRecipeName.Margin = new Padding(2);
            txtRecipeName.Name = "txtRecipeName";
            txtRecipeName.Size = new Size(121, 27);
            txtRecipeName.TabIndex = 3;
            // 
            // lblRecipeName
            // 
            lblRecipeName.AutoSize = true;
            lblRecipeName.Location = new Point(60, 83);
            lblRecipeName.Margin = new Padding(2, 0, 2, 0);
            lblRecipeName.Name = "lblRecipeName";
            lblRecipeName.Size = new Size(98, 20);
            lblRecipeName.TabIndex = 2;
            lblRecipeName.Text = "Recipe Name";
            // 
            // lblTypeofRecipe
            // 
            lblTypeofRecipe.AutoSize = true;
            lblTypeofRecipe.Location = new Point(51, 124);
            lblTypeofRecipe.Margin = new Padding(2, 0, 2, 0);
            lblTypeofRecipe.Name = "lblTypeofRecipe";
            lblTypeofRecipe.Size = new Size(107, 20);
            lblTypeofRecipe.TabIndex = 4;
            lblTypeofRecipe.Text = "Type of Recipe";
            // 
            // txtIngredients
            // 
            txtIngredients.Location = new Point(193, 166);
            txtIngredients.Margin = new Padding(2);
            txtIngredients.Name = "txtIngredients";
            txtIngredients.Size = new Size(121, 27);
            txtIngredients.TabIndex = 7;
            // 
            // lblIngredients
            // 
            lblIngredients.AutoSize = true;
            lblIngredients.Location = new Point(75, 173);
            lblIngredients.Margin = new Padding(2, 0, 2, 0);
            lblIngredients.Name = "lblIngredients";
            lblIngredients.Size = new Size(83, 20);
            lblIngredients.TabIndex = 6;
            lblIngredients.Text = "Ingredients";
            // 
            // txtSubmittedBy
            // 
            txtSubmittedBy.Location = new Point(193, 249);
            txtSubmittedBy.Margin = new Padding(2);
            txtSubmittedBy.Name = "txtSubmittedBy";
            txtSubmittedBy.Size = new Size(121, 27);
            txtSubmittedBy.TabIndex = 9;
            // 
            // lblVegetarian
            // 
            lblVegetarian.AutoSize = true;
            lblVegetarian.Location = new Point(78, 216);
            lblVegetarian.Margin = new Padding(2, 0, 2, 0);
            lblVegetarian.Name = "lblVegetarian";
            lblVegetarian.Size = new Size(80, 20);
            lblVegetarian.TabIndex = 8;
            lblVegetarian.Text = "Vegetarian";
            // 
            // lblSubmittedBy
            // 
            lblSubmittedBy.AutoSize = true;
            lblSubmittedBy.Location = new Point(101, 256);
            lblSubmittedBy.Margin = new Padding(2, 0, 2, 0);
            lblSubmittedBy.Name = "lblSubmittedBy";
            lblSubmittedBy.Size = new Size(57, 20);
            lblSubmittedBy.TabIndex = 10;
            lblSubmittedBy.Text = "Author:";
            // 
            // numPrepTimeMinutes
            // 
            numPrepTimeMinutes.Location = new Point(193, 37);
            numPrepTimeMinutes.Name = "numPrepTimeMinutes";
            numPrepTimeMinutes.Size = new Size(121, 27);
            numPrepTimeMinutes.TabIndex = 12;
            // 
            // chbVegeterian
            // 
            chbVegeterian.AutoSize = true;
            chbVegeterian.Location = new Point(193, 212);
            chbVegeterian.Name = "chbVegeterian";
            chbVegeterian.Size = new Size(18, 17);
            chbVegeterian.TabIndex = 13;
            chbVegeterian.UseVisualStyleBackColor = true;
            // 
            // cmbTypeOfRecipe
            // 
            cmbTypeOfRecipe.FormattingEnabled = true;
            cmbTypeOfRecipe.Location = new Point(193, 124);
            cmbTypeOfRecipe.Name = "cmbTypeOfRecipe";
            cmbTypeOfRecipe.Size = new Size(151, 28);
            cmbTypeOfRecipe.TabIndex = 14;
            // 
            // chbSpicy
            // 
            chbSpicy.AutoSize = true;
            chbSpicy.Location = new Point(194, 290);
            chbSpicy.Name = "chbSpicy";
            chbSpicy.Size = new Size(18, 17);
            chbSpicy.TabIndex = 16;
            chbSpicy.UseVisualStyleBackColor = true;
            // 
            // lblIsSpicy
            // 
            lblIsSpicy.AutoSize = true;
            lblIsSpicy.Location = new Point(114, 294);
            lblIsSpicy.Margin = new Padding(2, 0, 2, 0);
            lblIsSpicy.Name = "lblIsSpicy";
            lblIsSpicy.Size = new Size(44, 20);
            lblIsSpicy.TabIndex = 15;
            lblIsSpicy.Text = "Spicy";
            // 
            // btnSaveRecipe
            // 
            btnSaveRecipe.Location = new Point(194, 333);
            btnSaveRecipe.Name = "btnSaveRecipe";
            btnSaveRecipe.Size = new Size(94, 29);
            btnSaveRecipe.TabIndex = 17;
            btnSaveRecipe.Text = "Save Recipe";
            btnSaveRecipe.UseVisualStyleBackColor = true;
            btnSaveRecipe.Click += btnSaveRecipe_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(517, 374);
            Controls.Add(btnSaveRecipe);
            Controls.Add(chbSpicy);
            Controls.Add(lblIsSpicy);
            Controls.Add(cmbTypeOfRecipe);
            Controls.Add(chbVegeterian);
            Controls.Add(numPrepTimeMinutes);
            Controls.Add(lblSubmittedBy);
            Controls.Add(txtSubmittedBy);
            Controls.Add(lblVegetarian);
            Controls.Add(txtIngredients);
            Controls.Add(lblIngredients);
            Controls.Add(lblTypeofRecipe);
            Controls.Add(txtRecipeName);
            Controls.Add(lblRecipeName);
            Controls.Add(lblPrepTimeMinutes);
            Margin = new Padding(2, 2, 2, 2);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)numPrepTimeMinutes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPrepTimeMinutes;
        private TextBox txtRecipeName;
        private Label lblRecipeName;
        private Label lblTypeofRecipe;
        private TextBox txtIngredients;
        private Label lblIngredients;
        private TextBox txtSubmittedBy;
        private Label lblVegetarian;
        private Label lblSubmittedBy;
        private NumericUpDown numPrepTimeMinutes;
        private CheckBox chbVegeterian;
        private ComboBox cmbTypeOfRecipe;
        private CheckBox chbSpicy;
        private Label lblIsSpicy;
        private Button btnSaveRecipe;
    }
}
