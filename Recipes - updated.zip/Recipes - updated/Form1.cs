namespace Recipes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSaveRecipe_Click(object sender, EventArgs e)
        {
            if (cmbTypeOfRecipe.Text == "Main DIsh")
            {
                // Set up a main dish object


            }
            else if (cmbTypeOfRecipe.Text == "Dessert")
            {
                // Set up a dessert object
            }
            else
            {
                // asl the user to select a type of recipe
            }
        }
    }
}
