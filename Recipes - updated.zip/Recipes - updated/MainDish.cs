﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipes
{
    public class MainDish : Recipe, IServingSuggestion, IStorageDirections
    {
        private bool isSpicy;

        public bool IsSpicy { get; set; }

        //constructor 
        public MainDish(int newPrepTimeMinutes, string newRecipeName, string newCategory, string newIngredients, bool newIsVegetarian, string newSubmittedBy, bool newIsSpicy) : base(newPrepTimeMinutes, newRecipeName, newCategory, newIngredients, newIsVegetarian, newSubmittedBy)
        {
            IsSpicy = newIsSpicy;
        }

        public override string Display()
        {
            return "Main Dish Name: " + RecipeName + " | Spicy? " + IsSpicy;
        }

        //this implents the required serving from the IServingSuggestion interface
        public string GetServingSuggestion()
        {
            return "This main dish should be eaten with friends";
        }

        // this implements the required serving from the IStorageDirections
        public string ProvideStorageDirections()
        {
            return "Store in airtight container in refridgerator for up to 1 week.";
        }
    }
}
