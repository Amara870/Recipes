﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipes
{
    public class DessertRecipe : Recipe, IServingSuggestion
    {
    
        private bool requiresBaking;

        public bool RequiresBaking { get; set; }

        //constructor 
        public DessertRecipe(int newPrepTimeMinutes, string newRecipeName, string newCategory, string newIngredients, bool newIsVegetarian, string newSubmittedBy, bool newRequiresBaking) : base(newPrepTimeMinutes, newRecipeName, newCategory, newIngredients, newIsVegetarian, newSubmittedBy)
        {
            RequiresBaking = newRequiresBaking;
        }

        //we have to override the abstract Display method from the base class in each subclass
        public override string Display()
        {
            return "Dessert Name: " + RecipeName + " | Requires Baking " + RequiresBaking;
        }

        //this implents the required serving from the IServingSuggestion interface
        public string GetServingSuggestion()
        {
            return "This dessert should be eaten in 1 setting";
        }

        
       
        

        
    }
}
